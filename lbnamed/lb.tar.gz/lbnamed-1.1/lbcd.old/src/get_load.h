#ifndef LBCD_GET_LOAD_H
#define LBCD_GET_LOAD_H

int get_load(double *l1,double *l5, double *l15);

#endif
