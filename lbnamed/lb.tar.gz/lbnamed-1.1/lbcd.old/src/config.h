#ifndef LBCD_CONFIG_H
#define LBCD_CONFIG_H

#define PROGNAME "lbcd"
#define PID_FILE "/etc/leland/lbcd.pid"

#ifdef ultrix

#define C_HAS_HASH
#define C_VMUNIX "/vmunix"
#define C_KMEM "/dev/kmem"
#define C_UTMP "/etc/utmp"
#define USEPROTO

#elif defined(NeXT)

#define C_VMUNIX "/mach"
#define C_KMEM "/dev/kmem"
#define C_UTMP "/etc/utmp"
#define USEPROTO

#elif defined(sparc)

#define C_HAS_HASH
#define C_UTMP "/etc/utmp"

#elif defined(_AIX32) 
#define ibm
#define C_HAS_HASH
#define C_UTMP "/etc/utmp"
#define C_VMUNIX "/unix"
#define C_KMEM "/dev/kmem"

#elif defined(__alpha)

#define C_HAS_HASH
#define USEPROTO
#define C_UTMP UTMP_FILE
#endif

#include <stdio.h>

/* standard dsod includes */

#include "util.h"


#endif
