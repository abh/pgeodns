#include "config.h"
#include "proto_client.h"
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

int h_flag = 0;
int err_flag = 0;
char *h_arg;

void usage();

void send_request(char *host);

int main(int argc, char **argv)
{
   int c;
   extern int optind, opterr;
   extern char *optarg;
 
   while ((c = getopt(argc, argv, "h:")) != EOF) 
     switch (c) {
     case 'h':
         h_arg = optarg;
         h_flag = 1;
         break;
     default:
         err_flag++;
     }

  if (err_flag || !h_flag) (void)usage();
  send_request(h_arg);
}

void send_request(char *host)
{
   int s;
   struct sockaddr_in serv_addr, cli_addr;
   int cli_len,serv_len;
   int n; 
   int retry;
   char mesg[PROTO_MAXMESG];
   P_LB_RESPONSE_PTR lbr;
   LB_RESPONSE lb;

  /* open UDP socket */
  
  if (  (s = socket(AF_INET,SOCK_DGRAM, 0)) < 0 ) {
     fprintf(stderr,"can't open udp socket\n");
     exit(1);
  }

  bzero((char*)& serv_addr, sizeof(serv_addr));  
  serv_addr.sin_family = AF_INET;
  serv_addr.sin_addr.s_addr = util_get_ipaddress(host); 
if (serv_addr.sin_addr.s_addr==-1) {
   fprintf(stderr,"can't get ip address for %s\n",host);
   exit(1);
}
  serv_addr.sin_port = htons(PROTO_PORTNUM);

  bzero((char*)& cli_addr, sizeof(cli_addr));  
  cli_addr.sin_family = AF_INET;
  cli_addr.sin_addr.s_addr = htonl(INADDR_ANY);
  cli_addr.sin_port = htons(0);

  if (bind(s,(struct sockaddr *) &cli_addr, sizeof(cli_addr)) < 0) {
     fprintf(stderr,"can't bind udp socket\n");
     exit(1);
  }

  serv_len = sizeof(serv_addr);

  retry=5;
  while(--retry) {
printf("send_lb\n");
     proto_send_lb_request(s, (struct sockaddr *) &serv_addr, serv_len,0);  
     n=proto_recv_reply(s,mesg,sizeof(mesg),
              (struct sockaddr *)&serv_addr,&serv_len,1000);
     if (n!=-1) break;
  }

  if (n==-1) {
    printf("no response\n");
    exit(1);
  }

  lbr = (P_LB_RESPONSE_PTR) mesg;
  proto_unpack_lb_info(lbr,&lb);

printf("load averages     %.2f %.2f %.2f\n",lb.l1,lb.l5,lb.l15);
printf("current time      %s",ctime(&lb.current_time));
printf("boot time         %s",ctime(&lb.boot_time));
printf("total users       %d\n",lb.tot_users);
printf("unique users      %d\n",lb.uniq_users);
printf("last login/logout %s",ctime(&lb.user_mtime)); 
if (lb.on_console)  printf ("someone is on the console.\n");

exit(0);
}

void usage()
{

fprintf(stderr,"usage: lbi  %s -h host\n");
exit(1);

}

