#ifndef LBCD_PROTOCOL_CLIENT_H
#define LBCD_PROTOCOL_CLIENT_H

#include "protocol.h"

void proto_unpack_lb_info(P_LB_RESPONSE *in,LB_RESPONSE *out);
int proto_send_lb_request(int s, 
                   struct sockaddr *serv_addr, int serv_len,
                   int id);
int proto_recv_reply(int s, char *mesg, int max_mesg,
                   struct sockaddr *serv_addr, int *serv_len,
                   int msec_timeout);
#endif
