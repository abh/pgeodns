#ifndef LBCD_GET_TIME_H
#define LBCD_GET_TIME_H

int get_boottime(time_t *boottime);
int get_time(time_t *t);

#endif
