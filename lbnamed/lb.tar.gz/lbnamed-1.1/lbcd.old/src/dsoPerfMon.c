

int main(int argc, char **argv)
{
   double l1,l5,l15;
   long boot, current;

   get_load(&l1,&l5,&l15);
   get_boottime(&boot);
   get_time(&current);
   printf("LOAD: %.2f %.2f %.2f, UPTIME: %d seconds, NOW: %d seconds\n",
	  l1,l5,l15,current-boot,current);
}

