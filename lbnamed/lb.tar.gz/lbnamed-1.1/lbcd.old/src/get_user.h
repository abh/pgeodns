#ifndef LBCD_GET_USER_H
#define LBCD_GET_USER_H

int get_user_stats(int *total,int *unique, int *onconsole, time_t *user_mtime);

#endif

