
#include "config.h"

#include "get_time.h"

#include "kernel.h"

#ifdef ibm
#include <sys/types.h>
#include <sys/times.h>
#include <sys/param.h>
#include <time.h>
#endif

int get_boottime(time_t *boottime)
{
#if defined(ultrix) || defined(sparc) || defined(NeXT) || defined(__alpha)
 return kernel_getboottime(boottime);
#elif defined(ibm)

 time_t uptime,curr;
 struct tms tbuf;

 uptime = times(&tbuf) / HZ;
 curr = time((time_t*)0);
 *boottime = curr-uptime;
 return 0;
#endif

}

int get_time(time_t *t)
{
 time(t);
 return 0;
}

#ifdef test_me
main()
{
 time_t bt,ct;
 int status;

 kernel_open();

 status=get_boottime(&bt);

 printf("%d %d\n",status,bt);
 printf("%s\n",ctime(&bt));

 status=get_time(&ct);
 printf("%d %d\n",status,ct);
 printf("%s\n",ctime(&ct));

}

#endif
