#include "config.h"
#include "kernel.h"

#ifdef ultrix

#include <sys/fixpoint.h>
#include <nlist.h>
#include <time.h>
int kd = -1;

#elif sparc

#include <nlist.h>
#include <kvm.h>
#include <sys/param.h>
#include <sys/time.h>
kvm_t  *kd;

#elif NeXT

#include <nlist.h>
#include <sys/time.h>
#define FSCALE 1024.0

int kd = -1;

#elif _AIX

#include <nlist.h>
#include <time.h>
#include <stdio.h>
int kd = -1;

#elif __alpha

#include<sys/types.h>
#include<sys/table.h>

#endif

#if defined(ultrix) || defined(sparc)

static struct nlist nl[] = {
  { "_avenrun" },         /* load average */
#define K_NL_LOADAVERAGE 0
  { "_boottime" },         /* boottime */
#define K_NL_BOOTTIME 1
  { 0 }
};

#elif defined(NeXT)

static struct nlist nl[] = {
  { {"_avenrun"},0 },         /* load average */
#define K_NL_LOADAVERAGE 0
  { {"_boottime"},0 },        /* boot time */
#define K_NL_BOOTTIME 1
  {{0}, 0 }
};

#elif defined(_AIX)

static struct nlist nl[] = {
  { "avenrun",0,0,0,0,0 },         /* load average */
#define K_NL_LOADAVERAGE 0
  { NULL,0,0,0,0,0 },  
};

#endif

static int kernel_init=0;

int kernel_open()
{
#if defined(ultrix) || defined(NeXT)

  if ( (kd = open(C_KMEM, O_RDONLY)) < 0 ){
    util_log_error("can't open %s: %%m",C_KMEM);
    exit(1);
  }

  if (nlist(C_VMUNIX,nl) < 0) {
    util_log_error("no namelist for %s",C_VMUNIX);
    exit(1);
  }

#elif sparc

 if ((kd = kvm_open(NULL, NULL, NULL, O_RDONLY, PROGNAME)) == NULL) {
    util_log_error("kvm_open: %%m");
    exit(1);
 }

 if (kvm_nlist(kd, nl) !=0) {
    util_log_error("kvm_nlist error");
    exit(1);
 }
#elif _AIX

  if ( (kd = open(C_KMEM, O_RDONLY)) < 0 ){
    util_log_error("can't open %s: %%m",C_KMEM);
    exit(1);
  }

  if (knlist(nl, 1, sizeof(struct nlist)) == -1) {
    util_log_error("no namelist for %s",C_VMUNIX);
    exit(1);
  }

#endif

  kernel_init = 1;
  return 0;

}

int kernel_close()
{
if (! kernel_init) return;
#if defined(ultrix) || defined(NeXT) || defined(_AIX)
  return close(kd);
#elif sparc
  return kvm_close(kd);
#endif
}

int kernel_read(off_t where, void *dest, int dest_len)
{
   int stat;

#if defined(ultrix) || defined(NeXT) || defined(_AIX)
   if (lseek(kd,where,SEEK_SET)==-1) {
        util_log_error("can't lseek in %s: %%m",C_KMEM);
        exit(1);
   }

   stat=read(kd,dest,dest_len);
   if (stat==-1) {
          util_log_error("kernel read %s: %%m",C_KMEM);
          exit(1);
   }   
   return stat;
#elif sparc

 stat = kvm_read(kd, where, dest, dest_len);
 if (stat==-1) {
          util_log_error("kvm_read : %%m");
          exit(1);
 }   
 return stat;

#endif
}

#ifdef __alpha

int kernel_getload(double *l1, double *l5, double *l15)
{

struct tbl_loadavg load;
struct tbl_sysinfo sys;
struct utmp *ut;

  if (table(TBL_LOADAVG, 0, &load, 1, sizeof(load))==-1) {
   return -1;
  }

  if (load.tl_lscale) {
         *l1 = load.tl_avenrun.l[0]/(float)(load.tl_lscale);
         *l5 = load.tl_avenrun.l[1]/(float)(load.tl_lscale);
         *l15 = load.tl_avenrun.l[2]/(float)(load.tl_lscale);
  } else {
         *l1 = load.tl_avenrun.d[0];
         *l5 = load.tl_avenrun.d[1];
         *l15 = load.tl_avenrun.d[2];
  }
  return 0;
}

#else

int kernel_getload(double *l1, double *l5, double *l15)
{
#ifdef ultrix
  fix kern_avenrun[3];
#elif sparc
  long kern_avenrun[3];
#elif NeXT
  long kern_avenrun[3];
#elif _AIX
  int kern_avenrun[3];
#endif

if (!kernel_init) kernel_open();

#if defined(ultrix)||defined(sparc)||defined(NeXT)||defined(_AIX)

#ifndef _AIX
  if (nl[K_NL_LOADAVERAGE].n_type==0) return -1;
#endif

  if (kernel_read( nl[K_NL_LOADAVERAGE].n_value, 
                       (char *) kern_avenrun,sizeof(kern_avenrun))==-1) { 
     util_log_error("kernel loadaverage read error: %%m");
      return -1;
  }

#endif

#ifdef ultrix
  *l1 = FIX_TO_DBL(kern_avenrun[0]);  
  *l5 = FIX_TO_DBL(kern_avenrun[1]);  
  *l15 = FIX_TO_DBL(kern_avenrun[2]);  
#elif defined(sparc) || defined(NeXT)
  *l1 = (double)kern_avenrun[0]/FSCALE;
  *l5 = (double)kern_avenrun[1]/FSCALE;
  *l15 =(double)kern_avenrun[2]/FSCALE;
#elif defined(_AIX)
  *l1 = kern_avenrun[0]/65536.0;
  *l5 = kern_avenrun[1]/65536.0;
  *l15 = kern_avenrun[2]/65536.0;
#else
  *l1 = *l5 = *l15 = 0;
#endif

  return 0;
}

#endif

int kernel_getboottime(time_t *boottime)
{

#if defined(ultrix)||defined(sparc)||defined(NeXT)
struct timeval boot;

if (!kernel_init) kernel_open();

  if (nl[K_NL_BOOTTIME].n_type==0) return -1;

  if (kernel_read( nl[K_NL_BOOTTIME].n_value, 
                       (char *) &boot,sizeof(boot))==-1) {
     util_log_error("kernel boottime read error: %%m"); 
      return -1;
  }

  *boottime = boot.tv_sec;
#elif __alpha
  struct tbl_sysinfo sys;

  if (table(TBL_SYSINFO, 0, &sys, 1, sizeof(sys))==-1) return -1;
  *boottime = sys.si_boottime;

#else
  *boottime = 0;
#endif
  return 0;
}

