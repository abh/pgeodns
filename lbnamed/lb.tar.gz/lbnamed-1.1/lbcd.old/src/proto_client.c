
#include "config.h"
#include "proto_client.h"

#ifdef ultrix 
#include <time.h>
#elif sparc || __alpha
#include <sys/time.h>
#endif

void proto_unpack_lb_info(P_LB_RESPONSE *in,LB_RESPONSE *out)
{
  out->boot_time = ntohl(in->boot_time);
  out->current_time = ntohl(in->current_time);
  out->l1 = ntohs(in->l1)/100.0;
  out->l5 = ntohs(in->l5)/100.0;
  out->l15 =ntohs(in->l15)/100.0;

  out->user_mtime = ntohl(in->user_mtime);
  out->tot_users  = ntohs(in->tot_users);  
  out->uniq_users = ntohs(in->uniq_users);
  out->on_console = in->on_console;
}

int proto_send_lb_request(int s, 
                   struct sockaddr *serv_addr, int serv_len,
                   int id)
{
  P_HEADER ph;
  int n;

  ph.version = htons(PROTO_VERSION);
  ph.id = htons(id);
  ph.op = htons(op_lb_info_req);
  ph.status = htons(status_request);

  n=sendto(s,(char*)&ph,sizeof(ph),0,serv_addr,serv_len);
  if ( n == -1) return -1;
  else return 0;
}

int proto_recv_reply(int s, char *mesg, int max_mesg,
                   struct sockaddr *serv_addr, int *serv_len,
                   int timo)
{ 
 int n;
 P_HEADER_PTR ph;
 int nfound;
 struct timeval to;
 fd_set readset,writeset;

  to.tv_sec  = timo/1000;
  to.tv_usec = (timo - (to.tv_sec*1000))*1000;

  FD_ZERO(&readset);
  FD_ZERO(&writeset);
  FD_SET(s,&readset);
  nfound = select(s+1,&readset,&writeset,NULL,&to);
  if (nfound<0) {
       fprintf(stderr,"select error\n");
       exit(1);
  }
  if (nfound==0) return -1;  /* timeout */

 n=recvfrom(s,mesg,max_mesg,0,serv_addr,serv_len);

 if (n<sizeof(P_HEADER_PTR)) { return -1; }

 ph = (P_HEADER_PTR) mesg;
 ph->version = ntohs(ph->version);
 ph->id      = ntohs(ph->id);
 ph->op      = ntohs(ph->op);
 ph->status  = ntohs(ph->status);

 return n;

}

