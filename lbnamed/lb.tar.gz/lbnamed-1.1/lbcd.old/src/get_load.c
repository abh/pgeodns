
#include "config.h"

#include "get_load.h"

#include "kernel.h"

int get_load(double *l1,double *l5, double *l15)
{

 return kernel_getload(l1,l5,l15);

}

#ifdef test_me

main()
{
 double l1,l5,l15;
 int status;

 kernel_open();

 status=get_load(&l1,&l5,&l15);

 printf("%d %.2f %.2f %.2f\n",status,l1,l5,l15);

}

#endif

