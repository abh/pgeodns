#ifndef LBCD_KERNEL_H
#define LBCD_KERNEL_H

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#if defined(sparc) || defined(ultrix) 
#include <unistd.h>
#endif

int kernel_open();     
int kernel_close();
int kernel_getload(double *l1, double *l5, double *l15);
int kernel_getboottime(time_t *boottime);
int kernel_read(off_t where, void *dest, int dest_len);

#endif
