
package LBCD;

$proto_portnum = 4330;
$proto_maxmesg = 2048;
$proto_version = 2;

$op_lb_info                 =1;   # load balance info, request and reply

$status_request             =0; #  /* a request packet */
$status_ok                  =1; #  /* load balance info, request and reply */
$status_error               =2; #  /* generic error */
$status_proto_version       =3; #  /* protocol version error */
$status_proto_error         =4; #  /* generic protocol error */
$status_unknown_op          =5; #  /* unknown operation requested */

$p_header = "n n n n";
#typedef struct {
#  u_short   version;  /* protocol version */
#  u_short   id;       /* requestor's uniq request id */
#  u_short   op;       /* operation requested */
#  u_short   status;   /* set on reply */
#} P_HEADER,*P_HEADER_PTR;

$p_lb_response = $p_header . " N N N n n n n n C C";

#typedef struct {
#  P_HEADER h;
#  u_int boot_time;
#  u_int current_time;
#  u_int user_mtime;  /* time user information last changed */
#  u_short l1; /* (int) (load*100) */
#  u_short l5;
#  u_short l15;
#  u_short tot_users;  /* total number of users logged in */
#  u_short uniq_users; /* total number of uniq users */
#  u_char  on_console; /* true if somone on console */
#  u_char  reserved;   /* future use, padding... */
#} P_LB_RESPONSE, *P_LB_RESPONSE_PTR;
#

1;
