/*
 * lbcd kernel code for Solaris
 *
 * Uses kstat code in the Solaris FAQ written by Casper Dik
 * in the comp.unix.solaris post <3qh88s$6ho@engnews2.Eng.Sun.COM>.
 */

#include <string.h>
#include <stdio.h>
#include <sys/param.h>
#include <sys/times.h>
#include <limits.h>
#include <kstat.h>
#ifdef HAVE_CONFIG_H
#include "config.h"
#endif
#include "lbcd.h"
#include "util.h"

static int kernel_init=0;
static kstat_ctl_t *kc;

int
kernel_open()
{
  if ((kc = kstat_open()) == 0) { }

  kernel_init = 1;
  return 0;
}

int
kernel_close()
{
  if (! kernel_init) return;

  return kstat_close(kc);
}

int
kernel_getload(double *l1, double *l5, double *l15)
{
  kstat_t *ksp;
  kstat_named_t *kn1,*kn5,*kn15;
  long kern_avenrun[3];

  if (!kernel_init) kernel_open();

  if ((ksp = kstat_lookup(kc, "unix", 0, "system_misc")) == 0 ) {

    return -1;
  }

  if (kstat_read(kc, ksp, 0) == -1) {

    return -1;
  }

  if ((kn1 = kstat_data_lookup(ksp, "avenrun_1min")) == 0) {

    return -1;
  }
  if ((kn5 = kstat_data_lookup(ksp, "avenrun_5min")) == 0) {

    return -1;
  }
  if ((kn15 = kstat_data_lookup(ksp, "avenrun_15min")) == 0) {

    return -1;
  }

  *l1  = (double)kn1->value.ul/FSCALE;
  *l5  = (double)kn5->value.ul/FSCALE,
  *l15 = (double)kn15->value.ul/FSCALE;

  return 0;
}

int
kernel_getboottime(time_t *boottime)
{
  time_t uptime,curr;
  struct tms tbuf;

  uptime = times(&tbuf) / HZ;
  curr = time((time_t*)0);
  *boottime = curr-uptime;
}
