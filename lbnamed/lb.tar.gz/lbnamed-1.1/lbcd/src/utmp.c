/*
 * utmp.c
 *
 * print list of users on the host
 * By Larry Schwimmer (schwim@cyclone.stanford.edu)
 */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <fcntl.h>
#if HAVE_UTMPX_H
#include <utmpx.h>
#elif HAVE_UTMP_H
#include <utmp.h>
#else
#error No utmp code available on this host?
#endif
#include <pwd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>
#include <sys/time.h>
#include <ctype.h>

#define PRINT_NEWLINE(fp) fprintf(fp,"\n")

static const char *utmp =
#ifdef HAVE_UTMPX_H
  #ifdef UTMPX_FILE
    UTMPX_FILE
  #else
    "/etc/utmpx"
  #endif
#elif HAVE_UTMP_H
  #ifdef UTMP_FILE
    UTMP_FILE
  #else
    "/etc/utmp"
  #endif
#endif
;

/*
 * hidden
 *
 * Return 1 if user is hidden (has .nofinger), 0 otherwise
 */
int
hidden (const struct passwd *sp)
{
#ifdef HONOR_NOFINGER
  char buffer[1024];

  /* Safety check */
  if (sp == NULL || sp->pw_dir == NULL ||
      strlen(sp->pw_dir) >= (sizeof(buffer) - 12))
    return 0;

  /* Return if file exists */
  strcpy(buffer,sp->pw_dir);
  strcat(buffer,"/.nofinger");
  return (access(buffer,F_OK) == 0);
#else
  return 0;
#endif
}

void
print_banner(void)
{
#ifdef MAIN
    printf("Login        Name             TTY      Idle    When   Where");
    PRINT_NEWLINE(stdout);
#endif
}

int
read_users (void)
{
  int fd;
#ifdef HAVE_UTMPX_H
  struct utmpx ut;
#elif HAVE_UTMP_H
  struct utmp ut;
#endif
  int nread;
  time_t now = time(0);
  int did_banner = 0;

  if ((fd = open(utmp,O_RDONLY|O_NONBLOCK)) != -1) {
    while ((nread = read(fd,&ut,sizeof(ut))) > 0) {
#if HAVE_UTMPX_H
      if(ut.ut_type != USER_PROCESS) {
	continue;
      }
#endif
#ifdef HAVE_UTMPX_H
      if (ut.ut_user[0]) {
#elif HAVE_UTMP_H
      if (ut.ut_name[0]) {
#endif	
	char conbuf[257];
	char userbuf[9];
	char tty[33] = { '/', 'd', 'e', 'v', '/', '\0'};
	int console = ut.ut_line[0] == 'c';
	struct passwd *sp;
	struct stat statbuf;
	int idle = 0;
	int mesg = 0;
	char idlebuf[6] = {' ', ' ', ' ', ' ', '\0', '\0' };
	char whenbuf[10];
#ifdef HAVE_UTMPX_H
	struct tm *st = localtime(&ut.ut_tv.tv_sec);
#else
	struct tm *st = localtime(&ut.ut_time);
#endif

	strftime(whenbuf, sizeof(whenbuf), "%a %H:%M",st);
	strncpy(userbuf,ut.ut_name,8);
	userbuf[8] = '\0';	/* NUL terminate string */
	
	if (ut.ut_host[0] && isprint(ut.ut_host[0])) {
#ifdef HAVE_UTMPX_H
	  /* 11 characters takes us to column 79 */
 	  strncpy(conbuf,ut.ut_host,ut.ut_syslen > 11 ? 11 : ut.ut_syslen);
#elif HAVE_UTMP_H
	  /* 11 takes us to column 79; max is 16 */
	  strncpy(conbuf,ut.ut_host,11);
#endif
	} else {
	  if (console || (ut.ut_host[0] == '\0')) {
	    /* Local logins will show up as an empty host field */
	    *conbuf = '\0';
	  } else {
	    strcpy(conbuf,"unknown");
	  }
	}
#ifdef HAVE_UTMPX_H
	conbuf[ut.ut_syslen] = conbuf[11] = '\0';
#elif HAVE_UTMP_H
	conbuf[11] = '\0';
#endif
	strcat(tty,ut.ut_line);
	if (stat(tty,&statbuf) == 0) {
	  mesg = (statbuf.st_mode & (S_IWGRP | S_IWOTH));
	  idle = now - statbuf.st_atime;
	  if (idle >= 59) {
	    idle /= 60;		/* convert to minutes */
	    if (idle >= 60) {
	      if (idle >= 1440) { /* days */
		idle /= 1440;
		if (idle <= 999)
		  sprintf(idlebuf,"%3dd",idle);
		else		/* play it safe */
		  strcpy(idlebuf,"years");
	      } else {		/* hours */
		if (idle >= 600) { /* 10+ hours */
		  sprintf(idlebuf," %2dh",idle/60);
		} else {
		  sprintf(idlebuf,"%d:%02d",idle/60,idle%60);
		}
	      }
	    } else {		/* minutes */
	      sprintf(idlebuf,"  %2d",idle);
	    }
	  }
	}
	
	if (userbuf && (sp = getpwnam(userbuf)) != NULL) {
	  if (!hidden(sp)) {
	    char namebuf[21];

	    strncpy(namebuf,sp->pw_gecos,20);
	    namebuf[20] = '\0';

	    if (!did_banner) {
	      did_banner = 1;
	      print_banner();
	    }
	    printf("%-8s %-21s%c%-8s %4s %9s %-12s",
		   userbuf,
		   namebuf,
		   mesg ? ' ' : '*',
		   /* tty mapping
		    * pts/ttyXY -> ttyXY (HP-UX)
		    * All else to itself.
		    * Note: We do not use short names since Solaris does
		    *       not have them and we want to be consistent.
		    */
		   (ut.ut_line[0] == 'p' && ut.ut_line[4] == 't')
		   ? ut.ut_line+4 : ut.ut_line,
		   idlebuf,
		   whenbuf,
		   conbuf);
	    PRINT_NEWLINE(stdout);
	  }
	}
      }
    }
  }
  close(fd);

  return did_banner;
}


#ifdef MAIN
int
main()
{
  read_users();
  return 0;
}
#endif
