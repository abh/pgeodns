#!/usr/local/bin/perl
#######################################################################
#
# lbnamed.pl load balancing name server in perl
#
# $Id: lbnamed.pl,v 1.3 1994/07/23 03:19:14 schemers Exp schemers $
#
# $Log: lbnamed.pl,v $
# Revision 1.3  1994/07/23  03:19:14  schemers
# made changes to send back the IP address along with the CNAME.
#
# Revision 1.2  1994/07/18  21:20:40  schemers
# changed so lbnamed returned dynamic CNAMEs instead of A records
#
# Revision 1.1  1994/07/18  21:16:36  schemers
# Initial revision
#
#
#----------------------------------------------------------------------
# Copyright (c) 1994 Board of Trustees, Leland Stanford Jr. University
#######################################################################

require 'newgetopt.pl';
require 'ctime.pl';
require 'conf.pl';

&NGetOpt("i:i","f:s","d","l:s","n");

&usage       if !defined($opt_f);

$sleep_interval = $opt_i;
$config_file = $opt_f;
$log_file = $opt_l;
$debug = $opt_d;

&daemon unless ($opt_n);
&open_log($log_file) if ($log_file);
&start_poller if ($sleep_interval);

&load_config("$config_file.lb");
&init_dns_socket(*DNS_UDP,*DNS_TCP);
&init_signals;

&write_log("ready to answer requests");

while (1) {
    $rin=''; 
    vec($rin,fileno(DNS_UDP),1) = 1;
    vec($rin,fileno(DNS_TCP),1) = 1;
    $nfound = select($rout=$rin,undef,undef,undef);
    if ($nfound > 0) {
	$stats_input += $nfound;
	&handle_udp_dns_request(*DNS_UDP) if (vec($rout,fileno(DNS_UDP),1));
	&handle_tcp_dns_request(*DNS_TCP) if (vec($rout,fileno(DNS_TCP),1));
    }  
    &do_maint if ($need_maint);
}

sub handle_udp_dns_request {
    local(*DNS_UDP) = @_;
    local($buff,$reply);
    $stats_udp_request++;
    $from = recv(DNS_UDP,$buff,8192,0) || die "Can't receive: $!";
    $reply = &do_dns_request(*buff,*from);
    if ($reply) {
	$stats_output++;
	send(DNS_UDP,$reply,0,$from) || die "Can't send: $!";
    }
}

sub handle_tcp_dns_request {
    local(*DNS_TCP) = @_;
    local($from,$len,$buff,$reply,*S);

    $stats_tcp_request++;
    &write_log("in handle_tcp_dns_request") if $debug;
    if (!($from=accept(S,DNS_TCP))) {
	&write_log("handle_tcp_dns_request: Can't accept: $!");
	return;
    }
    if (fork) { 
	close(S);
    } else {
	close(DNS_TCP);
	while(sysread(S,$buff,2)) {
	    $len = unpack("n",$buff);
	    sysread(S,$buff,$len) || exit(1);
	    $reply = &do_dns_request(*buff,*from);
	    if ($reply) {
		send(S,pack("n",length($reply)),0) || die "Can't send: $!";
		send(S,$reply,0) || die "Can't send: $!";
	    }
	}
	close(DNS_TCP);
	exit(0);
    }
}

sub do_dns_request {
    local(*buff,*from) = @_;
    local($buff_len,$answer,$rcode,$response);
    local($id,$flags,$qdcount,$ancount,$nscount,$arcount);

    $buff_len   = length($buff);

    return '' if ($buff_len <= &dns'HEADERLEN); # short packet, ignore it.

    $header     = substr($buff,0,&dns'HEADERLEN);
    $question   = substr($buff,&dns'HEADERLEN);
    $ptr        = &dns'HEADERLEN;

    ($id,$flags,$qdcount,$ancount,$nscount,$arcount) = unpack("n6 C*",$header);

    $qr     = ($flags & &dns'QR_MASK) >> &dns'QR_SHIFT;
    $opcode = ($flags & &dns'OP_MASK) >> &dns'OP_SHIFT;
    $tc     = ($flags & &dns'TC_MASK) >> &dns'TC_SHIFT;
    $rd     = ($flags & &dns'RD_MASK) >> &dns'RD_SHIFT;

    return '' if ($qr);   # should not be set on a query, ignore packet

    $question_len = length($question);

    if ( &dns'dn_expand(*buff,$ptr,*qname,*comp_len)==0) {
        $flags |=  &dns'QR_MASK | &dns'AA_MASK | &dns'FORMERR;
        $response = pack("n n n n n n",$id,$flags,1,0,0,0);
        $response .= $question;
        $stats_formerr++;
        return $response;
    }

    $ptr += $comp_len;
    ($qtype,$qclass) = unpack("n n",substr($buff,$ptr,4));  
    $ptr +=4;
    $qtype_a = $dns'type2a{$qtype};
    $qclass_a = $dns'class2a{$qclass};
    $from_a = &inet_ntoa_sock($from);
    # &write_log("req: $qname ($qtype,$qclass)($qtype_a, $qclass_a) from: $from_a");

    if ( ($opcode != &dns'QUERY) ) {
        $flags |=  &dns'QR_MASK | &dns'AA_MASK | &dns'NOTIMP;
        $response = pack("n n n n n n",$id,$flags,1,0,0,0);
        $response .= $question;
        $stats_notimp++;
        return $response;
    }

    if ($ptr != $buff_len) { # we are not at end of packet (we should be :-) )
	$flags |=  &dns'QR_MASK | &dns'AA_MASK | &dns'FORMERR;
        $response = pack("n n n n n n",$id,$flags,1,0,0,0);
        $response .= $question;
        $stats_formerr++;
        return $response;
    }

    $full_qname = "\L$qname";
    $qname =~  s/\.stanford.edu$//i;
    $qname =~  s/\.best$//i;
    $qname =~  s/\-best$//i;
    $qname = "\L$qname";

    if ($answer = $db{"$qtype $qclass $qname"}) {
       $flags |=  &dns'QR_MASK | &dns'AA_MASK | &dns'NOERROR;
       $response = pack("n n n n n n",$id,$flags,1,1,0,0);
       $response .= $question;
       $response .= &dns'aaa_section(
                  pack("n",0xc00c),
                  $qtype,
                  $qclass,
                  3600,
                  $answer);
       return $response;
    }

    if ($qtype == &dns'T_SOA 
            && ( ($full_qname eq 'best.stanford.edu') 
              || ($full_qname eq 'test-best.stanford.edu'))) {
       $answer = &dns'aaa_section(
                  pack("n",0xc00c),
                  &dns'T_SOA, &dns'C_IN, 88640,
                  &dns'rr_SOA("dsodb.stanford.edu",
                              "schemers.slapshot.stanford.edu",
                              time,
                              86400, 86400, 86400, 0));
       $ancount = 1;
       $arcount = 0;
       $stats_T_mx++;
       $flags |=  &dns'QR_MASK | &dns'AA_MASK | &dns'NOERROR;
       $response = pack("n n n n n n",$id,$flags,1,$ancount,0,$arcount);
       $response .= $question;
       $response .= $answer;
       return $response;
    }

    if (!$groups{$qname}) {
       $flags |=  &dns'QR_MASK | &dns'AA_MASK | &dns'NXDOMAIN;
       $response = pack("n n n n n n",$id,$flags,1,0,0,0);
       $response .= $question;
       $stats_nxdomain++;
       return $response;
    }
  
    $stats_query{$qname}++;

    if ($qtype == &dns'T_A || $qtype == &dns'T_MX || $qtype == &dns'T_ANY) {
#    $ipaddess = eval "&get_best(*group_$qname);";
#    $answer = &dns'aaa_section(
#                  pack("n",0xc00c),
#                  &dns'T_A,&dns'C_IN,0,
#                  &dns'rr_A($ipaddress));
        $the_host = eval "&get_best(*group_$qname);";
        $the_ip    = $ip_host{$the_host};
        $the_host .= ".stanford.edu" if ($the_host !~ /\.stanford\.edu/i);

        $answer .= &dns'aaa_section(
                  pack("n",0xc00c),
                  &dns'T_CNAME,&dns'C_IN,0,
                  &dns'rr_CNAME($the_host));

        $answer .= &dns'aaa_section(
                  &dns'simple_dname($the_host),
                  &dns'T_A,&dns'C_IN,3600,
                  &dns'rr_A($the_ip));

        $ancount = 2;
        $arcount = 0;
        $stats_T_a++;

    } else {
        $flags |=  &dns'QR_MASK | &dns'AA_MASK | &dns'NXDOMAIN;
        $response = pack("n n n n n n",$id,$flags,1,0,0,0);
        $response .= $question;
        $stats_nxdomain++;
        return $response;
    }

    $flags |=  &dns'QR_MASK | &dns'AA_MASK | &dns'NOERROR;
    $response = pack("n n n n n n",$id,$flags,1,$ancount,0,$arcount);
    $response .= $question;
    $response .= $answer;
    return $response;
}

sub by_weight { $weight{$a} <=> $weight{$b}; }

sub get_best {
    local(*group)=@_;
    local($best);

    @group = sort by_weight @group; 
    $best = @group[0];
    $weight{$best} += 200;
    return $best;
}
   
sub daemon {
    local(*TTY,*NULL);

    exit(0) if (fork);
    if (open(NULL,&_PATH_NULL)) {
	open(STDIN,">&NULL") || close(STDIN);
	open(STDOUT,">&NULL") || close(STDOUT);
	open(STDERR,">&NULL") || close(STDERR);
    } else {
	close(STDIN);
	close(STDOUT);
	close(STDERR);
    }
    eval 'require "sys/ioctl.ph";';
    return if !defined(&TIOCNOTTY);
    open(TTY,"+>/dev/tty") || return;
    ioctl(TTY,&TIOCNOTTY,0);
    close(TTY);
}

sub init_dns_socket {
    local(*UDP_SOCK,*TCP_SOCK) = @_;

    chop($hostname=`hostname`);
    local($name, $aliases, $type, $len, $clientaddr) = 
                                              gethostbyname($hostname);

    die "unable to get my ip address!" if ($name eq '');

    $client = pack($sockaddr_t,&PF_INET, &dns'NAMESERVER_PORT,$clientaddr);
    socket(UDP_SOCK,&AF_INET,&SOCK_DGRAM,0) || die "socket: $!";
    bind(UDP_SOCK,$client) || die "bind: $!";

    $client = pack($sockaddr_t,&PF_INET, &dns'NAMESERVER_PORT,$clientaddr);
    socket(TCP_SOCK,&AF_INET,&SOCK_STREAM,0) || die "socket: $!";
    setsockopt(TCP_SOCK, &SOL_SOCKET, &SO_REUSEADDR, 1);
    bind(TCP_SOCK,$client) || die "bind: $!";
    listen(TCP_SOCK,5) || die"listen: $!";
}

sub load_config {
    local($file) = @_;
    local($host);
    &write_log("load_config") if $debug;
    %weight=();
    foreach $group (keys %groups) { eval "@group_$group=();"; }
    %groups=();

   open(CONFIG,$file) || &write_log("Can't open config file: $!");
   while(<CONFIG>) {
       s/^\s+//;
       s/\s+$//;
       next if /^#/ || /^$/;
       ($weight,$host,$ip,$groups) = split(/\s+/,$_,4);
       print "  loading $_\n" if $debug;
       $_ = $ip;
       ($a,$b,$c,$d) =  /(\d+)\.(\d+)\.(\d+)\.(\d+)/;
       $ipaddr = ($a<<24)|($b<<16)|($c<<8)|$d;
       $ip_host{$host} = $ipaddr;
       $weight{$host} = $weight;
       foreach $group (split(/\s+/,$groups)) {
	   $groups{$group} += 1;
#          eval "push(@group_$group,\$ipaddr);";
	   eval "push(@group_$group,\$host);";
       }
    }
    chop($reload_time=&ctime(time));
    $db{"$dns_t_txt $dns_c_hs reload"} = &dns'rr_TXT($reload_time);
}

sub init_signals {
    $SIG{'HUP'} = 'catch_hup';
    $SIG{'USR1'} = 'catch_usr1';
    $SIG{'CHLD'} = 'restart_poller';
    $SIG{'INT'} = 'clean_exit';
    $SIG{'QUIT'} = 'clean_exit';
    $SIG{'TERM'} = 'clean_exit';
}

sub clean_exit {
    &write_log("received signal, exiting...") ;
    $SIG{'CHLD'} = 'IGNORE';
    if ($poller_id) {
	&write_log("killing poller($poller_id)");
	kill 'INT',$poller_id;
    }
    &close_log;
    exit(0);
}

sub start_poller {
    &write_log("starting poller");
    if (($poller_id=fork)==0) { 
       exec "./poller.pl -d -s -f $config_file -i $sleep_interval";
    }
}

sub restart_poller {
    local($pid) = wait;
    &write_log("restart_poller: ($pid != $poller_id)") if $debug;
    return if ($pid != $poller_id);
    &write_log("restarting poller");
    if (($poller_id=fork)==0) { 
       exec "./poller.pl -d -s -f $config_file -i $sleep_interval";
   }
   $stats_poller_starts++;
}

sub catch_usr1 {
    local(*DUMP);
    local($group);

    &write_log("dumping stats...");
    open(DUMP,">/usr/tmp/lbnamed.dump");
    print DUMP "\n";
    printf(DUMP "%12d  input packets\n",$stats_input);
    printf(DUMP "%12d  output packets\n",$stats_ouput);
    printf(DUMP "%12d  udp queries\n",$stats_udp_request);
    printf(DUMP "%12d  tcp queries\n",$stats_tcp_request);
    printf(DUMP "%12d  A queries\n",$stats_T_a);
    printf(DUMP "%12d  MX queries\n",$stats_T_mx);
    printf(DUMP "%12d  formerr answers\n",$stats_formerr);
    printf(DUMP "%12d  notimp answers\n",$stats_notimp);
    printf(DUMP "%12d  nxdomain answers\n",$stats_nxdomain);
    printf(DUMP "%12d  poller restarts\n",$stats_poller_starts);
    printf(DUMP "%12d  config reloads\n",$stats_config_reload);
    print DUMP "\n";

    foreach $group (sort keys %groups) {
      print DUMP "  $group has $groups{$group} entries\n";
    }
    print DUMP "\n";
    foreach $group (sort keys %stats_query) {
      print DUMP "  $group had $stats_query{$group} queries\n";
    }
    print DUMP "\n";
    close(DUMP);
} 

sub catch_hup { $need_maint=1; $need_reload=1; }

sub do_maint {
    &write_log("do_maint") if $debug;
    if ($need_reload) {
        &write_log("reloading config") if $debug;
        $stats_config_reload++;
        &load_config("$config_file.lb");
	$need_reload=0;
    }
    $need_maint=0;
}

sub inet_ntoa {
    local($ip) = @_;
    local($a,$b,$c,$d) = unpack('C4',$ip);
    return "$a.$b.$c.$d";
}

sub inet_ntoa_sock {
    local($addr) = @_;
    local($pf,$port,$ip) = unpack($sockaddr_t,$addr);
    local($a,$b,$c,$d) = unpack('C4',$ip);
    return "$a.$b.$c.$d";
}

sub open_log {
    local($file)=@_;
    &close_log if ($log_logging);
    open(LOGFILE,">>$file") || die "can't open $file: $!";
    $log_logging = 1;
    select(LOGFILE); $| =1;
}

sub close_log {
    close(LOGFILE) if ($log_logging);
    $log_logging=0;
}

sub write_log {
    local($message)=@_;
    local($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)
        = localtime(time);
    local($date)=sprintf("%02d/%02d %02d:%02d",$mon+1,$mday,$hour,$min);
    print LOGFILE "$date $$ lbnamed $message\n" if ($log_logging);
}

sub usage {
  print<<EOF;

Usage:  $0 -f configfile
  -i interval      time between polls
  -f configfile    configuration file
  -d               debug
  -l logfile       logfile
  -n                don't fork

EOF

 exit(1);
}

