# system dependent stuff

require 'dns.pl';

sub _PATH_TTY  { "/dev/tty";  }
sub _PATH_NULL { "/dev/null"; }

$sockaddr_t = 'S n a4 x8';

eval "require 'sys/socket.ph'";

eval <<'END_SOCKET_DEFINITIONS' if $@;
  sub AF_INET           { 2; }
  sub SOCK_STREAM       { 1; }
  sub SOCK_DGRAM        { 2; }
  sub SOL_SOCKET        { 65535; }
  sub SO_REUSEADDR      { 4; }
  sub AF_INET           { 2; }
  sub PF_INET           { 2; }
END_SOCKET_DEFINITIONS

#$dns_c_in = &dns'C_IN;
#$dns_c_hs = &dns'C_HS;
#$dns_t_txt = &dns'T_TXT;
#
#%db = (
# "$dns_t_txt $dns_c_hs zephyr.sloc.ns",&dns'rr_TXT("dsodb.stanford.edu")
#
#);

1;
